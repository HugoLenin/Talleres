package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ComboTest {

    private Combo combo;
    private static final double DESCUENTO = 0.93;
    private static final String NOMBRE = "todoterreno";

    @BeforeEach
    void setUp() {
        ArrayList<ProductoMenu> productos = new ArrayList<>();
        productos.add(new ProductoMenu("todoterreno", 25000));
        productos.add(new ProductoMenu("papas grandes", 6900));
        productos.add(new ProductoMenu("gaseosa", 5000));
        
        combo = new Combo(NOMBRE, DESCUENTO, productos);
    }

    @Test
    void testGetNombre() {
        assertEquals(NOMBRE, combo.getNombre(), "El nombre del combo no es correcto");
    }

    @Test
    void testGetPrecio() {
        int precioBase = 25000 + 6900 + 5000;
        int precioEsperado = (int)(precioBase * DESCUENTO);
        assertEquals(precioEsperado, combo.getPrecio(), "El precio con descuento no es correcto");
    }

    @Test
    void testGenerarTextoFactura() {
        String expected = "Combo " + NOMBRE + "\n" +
                         " Descuento: " + DESCUENTO + "\n" +
                         "            " + combo.getPrecio() + "\n";
        
        assertEquals(expected, combo.generarTextoFactura(), "El formato de factura no coincide");
    }
}