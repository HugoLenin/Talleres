package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

@DisplayName("Pruebas para ProductoAjustado")
class ProductoAjustadoTest {

    private static final String NOMBRE_BASE = "especial";
    private static final int PRECIO_BASE = 24000;
    private static final String NOMBRE_QUESO = "queso americano";
    private static final int COSTO_QUESO = 2500;
    private static final String NOMBRE_CEBOLLA = "cebolla";
    private static final int COSTO_CEBOLLA = 1000;
    private static final String NOMBRE_LECHUGA = "lechuga";
    
    private ProductoMenu productoBase;
    private Ingrediente queso;
    private Ingrediente cebolla;
    private Ingrediente lechuga;
    private ProductoAjustado productoAjustado;

    @BeforeEach
    void configurarProducto() {
        productoBase = new ProductoMenu(NOMBRE_BASE, PRECIO_BASE);
        queso = new Ingrediente(NOMBRE_QUESO, COSTO_QUESO);
        cebolla = new Ingrediente(NOMBRE_CEBOLLA, COSTO_CEBOLLA);
        lechuga = new Ingrediente(NOMBRE_LECHUGA, 0);
        
        productoAjustado = new ProductoAjustado(productoBase);
        productoAjustado.getAgregados().add(queso);
        productoAjustado.getAgregados().add(cebolla);
        productoAjustado.getEliminados().add(lechuga);
    }

    @Nested
    @DisplayName("Pruebas de propiedades básicas")
    class PropiedadesBasicas {
        
        @Test
        @DisplayName("Debería retornar el nombre correcto del producto base")
        void testGetNombre() {
            assertEquals(NOMBRE_BASE, productoAjustado.getNombre(), 
                "El nombre del producto ajustado no coincide con el producto base");
        }

        @Test
        @DisplayName("Debería retornar el producto base correctamente")
        void testGetProductoBase() {
            ProductoMenu base = productoAjustado.getProductoBase();
            assertAll("Verificación de producto base",
                () -> assertEquals(NOMBRE_BASE, base.getNombre()),
                () -> assertEquals(PRECIO_BASE, base.getPrecio())
            );
        }
    }

    @Nested
    @DisplayName("Pruebas de modificación de ingredientes")
    class ModificacionIngredientes {
        
        @Test
        @DisplayName("Debería manejar correctamente los ingredientes agregados")
        void testGetAgregados() {
            ArrayList<Ingrediente> agregados = productoAjustado.getAgregados();
            
            assertEquals(2, agregados.size(), "Debería tener 2 ingredientes agregados");
            
            assertAll("Verificación de ingredientes agregados",
                () -> assertEquals(NOMBRE_QUESO, agregados.get(0).getNombre()),
                () -> assertEquals(COSTO_QUESO, agregados.get(0).getCostoAdicional()),
                () -> assertEquals(NOMBRE_CEBOLLA, agregados.get(1).getNombre()),
                () -> assertEquals(COSTO_CEBOLLA, agregados.get(1).getCostoAdicional())
            );
        }

        @Test
        @DisplayName("Debería manejar correctamente los ingredientes eliminados")
        void testGetEliminados() {
            ArrayList<Ingrediente> eliminados = productoAjustado.getEliminados();
            
            assertEquals(1, eliminados.size(), "Debería tener 1 ingrediente eliminado");
            assertEquals(NOMBRE_LECHUGA, eliminados.get(0).getNombre(),
                "El ingrediente eliminado no coincide");
        }
    }

    @Nested
    @DisplayName("Pruebas de cálculo de precios")
    class CalculoPrecios {
        
        @Test
        @DisplayName("Debería calcular correctamente el precio con ingredientes adicionales")
        void testGetPrecio() {
            int precioEsperado = PRECIO_BASE + COSTO_QUESO + COSTO_CEBOLLA;
            assertEquals(precioEsperado, productoAjustado.getPrecio(),
                "El precio calculado no es correcto");
        }

        @Test
        @DisplayName("Debería calcular correctamente el precio sin modificaciones")
        void testPrecioSinModificaciones() {
            ProductoAjustado sinModificaciones = new ProductoAjustado(productoBase);
            assertEquals(PRECIO_BASE, sinModificaciones.getPrecio(),
                "El precio sin modificaciones debería ser igual al producto base");
        }
    }

    @Nested
    @DisplayName("Pruebas de generación de factura")
    class GeneracionFactura {
        
        @Test
        @DisplayName("Debería generar el texto de factura correctamente")
        void testGenerarTextoFactura() {
            String factura = productoAjustado.generarTextoFactura();
            
            assertAll("Verificación de contenido de factura",
                () -> assertTrue(factura.contains(NOMBRE_BASE)),
                () -> assertTrue(factura.contains(String.valueOf(PRECIO_BASE))),
                () -> assertTrue(factura.contains("+ " + NOMBRE_QUESO)),
                () -> assertTrue(factura.contains("+ " + NOMBRE_CEBOLLA)),
                () -> assertTrue(factura.contains("- " + NOMBRE_LECHUGA)),
                () -> assertTrue(factura.contains("Costo adicional de: " + COSTO_QUESO)),
                () -> assertTrue(factura.contains("Costo adicional de: " + COSTO_CEBOLLA)),
                () -> assertTrue(factura.contains("El costo total de su producto es de: " + 
                    (PRECIO_BASE + COSTO_QUESO + COSTO_CEBOLLA)))
            );
        }
    }

    @Nested
    @DisplayName("Pruebas de casos especiales")
    class CasosEspeciales {
        
        @Test
        @DisplayName("Debería manejar múltiples instancias del mismo ingrediente")
        void testIngredienteRepetido() {
            productoAjustado.getAgregados().add(new Ingrediente(NOMBRE_QUESO, COSTO_QUESO));
            
            assertEquals(3, productoAjustado.getAgregados().size(),
                "Debería permitir ingredientes repetidos");
            
            int precioEsperado = PRECIO_BASE + (COSTO_QUESO * 2) + COSTO_CEBOLLA;
            assertEquals(precioEsperado, productoAjustado.getPrecio(),
                "Debería sumar el costo de ingredientes repetidos");
        }
    }
}
