package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

@DisplayName("Pruebas para la clase Pedido")
class PedidoTest {

    private static final String NOMBRE_CLIENTE = "Carlos Gómez";
    private static final String DIRECCION_CLIENTE = "Calle 123";
    private static final String ARCHIVO_PRUEBA = "factura_test.txt";
    
    private Pedido pedido;
    private File archivoFactura;

    @BeforeEach
    void configurarPedido() throws Exception {
        pedido = new Pedido(NOMBRE_CLIENTE, DIRECCION_CLIENTE);
        pedido.agregarProducto(new ProductoMenu("corral", 14000));
        pedido.agregarProducto(new ProductoMenu("papas medianas", 5500));
        pedido.agregarProducto(new ProductoMenu("gaseosa", 5000));
        
        archivoFactura = new File(ARCHIVO_PRUEBA);
    }

    @AfterEach
    void limpiarArchivos() {
        if (archivoFactura.exists()) {
            archivoFactura.delete();
        }
    }

    @Nested
    @DisplayName("Pruebas de propiedades básicas")
    class PropiedadesBasicas {
        
        @Test
        @DisplayName("Debería generar un ID de pedido válido")
        void testIdPedidoValido() {
            assertTrue(pedido.getIdPedido() >= 0, "El ID del pedido debe ser no negativo");
            
            // Verificar que los IDs son secuenciales
            Pedido nuevoPedido = new Pedido("Nuevo Cliente", "Otra dirección");
            assertEquals(pedido.getIdPedido() + 1, nuevoPedido.getIdPedido(),
                "Los IDs de pedido deberían ser secuenciales");
        }

        @Test
        @DisplayName("Debería retornar correctamente el nombre del cliente")
        void testNombreCliente() {
            assertEquals(NOMBRE_CLIENTE, pedido.getNombreCliente(),
                "El nombre del cliente no coincide con el esperado");
        }
    }

    @Nested
    @DisplayName("Pruebas de cálculo de precios")
    class CalculoPrecios {
        
        @Test
        @DisplayName("Debería calcular correctamente el precio total con IVA")
        void testPrecioTotal() {
            int precioEsperado = 14000 + 5500 + 5000;
            int ivaEsperado = (int)(precioEsperado * 0.19);
            int totalEsperado = precioEsperado + ivaEsperado;
            
            assertEquals(totalEsperado, pedido.getPrecioTotalPedido(),
                "El precio total calculado no es correcto");
        }
    }

    @Nested
    @DisplayName("Pruebas de generación de factura")
    class GeneracionFactura {
        
        @Test
        @DisplayName("Debería generar el texto de factura correctamente")
        void testTextoFactura() {
            String factura = pedido.generarTextoFactura();
            
            assertAll("Validación de estructura de factura",
                () -> assertTrue(factura.contains("Cliente: " + NOMBRE_CLIENTE),
                    "Falta el nombre del cliente en la factura"),
                () -> assertTrue(factura.contains("Dirección: " + DIRECCION_CLIENTE),
                    "Falta la dirección en la factura"),
                () -> assertTrue(factura.contains("corral"),
                    "Falta producto 'corral' en la factura"),
                () -> assertTrue(factura.contains("papas medianas"),
                    "Falta producto 'papas medianas' en la factura"),
                () -> assertTrue(factura.contains("gaseosa"),
                    "Falta producto 'gaseosa' en la factura"),
                () -> assertTrue(factura.contains("Precio Neto:"),
                    "Falta precio neto en la factura"),
                () -> assertTrue(factura.contains("IVA:"),
                    "Falta IVA en la factura"),
                () -> assertTrue(factura.contains("Precio Total:"),
                    "Falta precio total en la factura")
            );
        }

        @Test
        @DisplayName("Debería guardar correctamente la factura en archivo")
        void testGuardarFactura() throws FileNotFoundException {
            pedido.guardarFactura(archivoFactura);
            
            assertTrue(archivoFactura.exists(), "El archivo de factura no se creó");
            
            StringBuilder contenido = new StringBuilder();
            try (Scanner sc = new Scanner(archivoFactura)) {
                while (sc.hasNextLine()) {
                    contenido.append(sc.nextLine()).append("\n");
                }
            }
            
            assertEquals(pedido.generarTextoFactura(), contenido.toString(),
                "El contenido del archivo no coincide con la factura generada");
        }
    }

    @Nested
    @DisplayName("Pruebas de casos especiales")
    class CasosEspeciales {
        
        @Test
        @DisplayName("Debería manejar pedido vacío correctamente")
        void testPedidoVacio() {
            Pedido pedidoVacio = new Pedido("Cliente", "Dirección");
            
            assertEquals(0, pedidoVacio.getPrecioTotalPedido(),
                "El precio total de pedido vacío debería ser 0");
        }
    }
}
