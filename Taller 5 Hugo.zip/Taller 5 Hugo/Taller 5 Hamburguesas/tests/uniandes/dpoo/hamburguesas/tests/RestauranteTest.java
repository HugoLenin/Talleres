package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.excepciones.*;
import uniandes.dpoo.hamburguesas.mundo.*;

public class RestauranteTest {

    private Restaurante sistemaRestaurante;

    @BeforeEach
    void inicializar() throws Exception {
        sistemaRestaurante = new Restaurante();
        sistemaRestaurante.cargarInformacionRestaurante(
            new File("data/ingredientes.txt"),
            new File("data/menu.txt"),
            new File("data/combos.txt")
        );
    }

    @Test
    void pruebaIniciarPedido() throws YaHayUnPedidoEnCursoException {
        sistemaRestaurante.iniciarPedido("Ana Pérez", "Carrera 45 #123");
        assertNotNull(sistemaRestaurante.getPedidoEnCurso(), "No se pudo iniciar el pedido.");
    }

    @Test
    void pruebaCerrarYGuardarPedido() throws Exception {
        sistemaRestaurante.iniciarPedido("Laura Ríos", "Calle 99");
        sistemaRestaurante.getPedidoEnCurso().agregarProducto(new ProductoMenu("corral", 14000));
        sistemaRestaurante.getPedidoEnCurso().agregarProducto(new ProductoMenu("papas medianas", 5500));
        sistemaRestaurante.getPedidoEnCurso().agregarProducto(new ProductoMenu("gaseosa", 5000));

        int idPedido = sistemaRestaurante.getPedidoEnCurso().getIdPedido();
        File archivoFacturaGenerada = new File("facturas/factura_" + idPedido + ".txt");

        sistemaRestaurante.cerrarYGuardarPedido();

        assertTrue(archivoFacturaGenerada.exists(), "La factura no fue creada.");
        assertFalse(archivoFacturaGenerada.length() == 0, "La factura está vacía.");
        assertNull(sistemaRestaurante.getPedidoEnCurso(), "El pedido no se cerró tras guardar la factura.");

        StringBuilder contenidoFactura = new StringBuilder();
        Scanner scanner = new Scanner(archivoFacturaGenerada);
        while (scanner.hasNextLine()) {
            contenidoFactura.append(scanner.nextLine()).append("\n");
        }
        scanner.close();

        String facturaTexto = contenidoFactura.toString();
        assertTrue(facturaTexto.contains("Cliente: Laura Ríos"));
        assertTrue(facturaTexto.contains("Dirección: Calle 99"));
        assertTrue(facturaTexto.contains("corral"));
        assertTrue(facturaTexto.contains("papas medianas"));
        assertTrue(facturaTexto.contains("gaseosa"));
    }

    @Test
    void pruebaObtenerPedidoEnCurso() throws YaHayUnPedidoEnCursoException {
        sistemaRestaurante.iniciarPedido("Carlos Gómez", "Calle 45");
        Pedido pedidoEnCurso = sistemaRestaurante.getPedidoEnCurso();
        assertNotNull(pedidoEnCurso);
        assertEquals("Carlos Gómez", pedidoEnCurso.getNombreCliente());
    }

    @Test
    void pruebaObtenerPedidos() {
        ArrayList<Pedido> listaPedidos = sistemaRestaurante.getPedidos();
        assertNotNull(listaPedidos);
        assertTrue(listaPedidos instanceof ArrayList);
    }

    @Test
    void pruebaObtenerMenuBase() {
        ArrayList<ProductoMenu> menu = sistemaRestaurante.getMenuBase();
        assertFalse(menu.isEmpty());
        assertTrue(menu.stream().anyMatch(p -> p.getNombre().equalsIgnoreCase("corral")));
    }

    @Test
    void pruebaObtenerMenuCombos() {
        ArrayList<Combo> combos = sistemaRestaurante.getMenuCombos();
        assertFalse(combos.isEmpty());
        assertTrue(combos.stream().anyMatch(c -> c.getNombre().toLowerCase().contains("todoterreno")));
    }

    @Test
    void pruebaObtenerIngredientes() {
        ArrayList<Ingrediente> ingredientes = sistemaRestaurante.getIngredientes();
        assertFalse(ingredientes.isEmpty());
        assertTrue(ingredientes.stream().anyMatch(i -> i.getNombre().equalsIgnoreCase("lechuga")));
    }

    @Test
    void pruebaCargarInformacionRestaurante() {
        Restaurante nuevoRestaurante = new Restaurante();
        assertDoesNotThrow(() -> {
            nuevoRestaurante.cargarInformacionRestaurante(
                new File("data/ingredientes.txt"),
                new File("data/menu.txt"),
                new File("data/combos.txt")
            );
        }, "No debería haber excepción al cargar la información del restaurante.");
    }
}
