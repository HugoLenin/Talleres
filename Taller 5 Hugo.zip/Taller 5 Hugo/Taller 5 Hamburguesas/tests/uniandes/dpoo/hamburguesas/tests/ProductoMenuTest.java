package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

@DisplayName("Pruebas para ProductoMenu")
class ProductoMenuTest {

    private static final String NOMBRE_PRODUCTO = "mexicana";
    private static final int PRECIO_PRODUCTO = 22000;
    
    private ProductoMenu producto;

    @BeforeEach
    void configurarProducto() {
        producto = new ProductoMenu(NOMBRE_PRODUCTO, PRECIO_PRODUCTO);
    }

    @Nested
    @DisplayName("Pruebas de propiedades básicas")
    class PropiedadesBasicas {
        
        @Test
        @DisplayName("Debería retornar el nombre correcto del producto")
        void testGetNombre() {
            assertEquals(NOMBRE_PRODUCTO, producto.getNombre(), 
                "El nombre del producto no coincide con el esperado");
        }

        @Test
        @DisplayName("Debería retornar el precio base correcto")
        void testGetPrecio() {
            assertEquals(PRECIO_PRODUCTO, producto.getPrecio(),
                "El precio del producto no coincide con el esperado");
        }
    }

    @Nested
    @DisplayName("Pruebas de generación de factura")
    class GeneracionFactura {
        
        @Test
        @DisplayName("Debería generar el texto de factura correctamente")
        void testGenerarTextoFactura() {
            String facturaEsperada = String.format("        %s\n        %d\n", NOMBRE_PRODUCTO, PRECIO_PRODUCTO);
            assertEquals(facturaEsperada, producto.generarTextoFactura(),
                "El formato de la factura no es correcto");
        }

        @Test
        @DisplayName("Debería incluir el nombre del producto en la factura")
        void testFacturaContieneNombre() {
            assertTrue(producto.generarTextoFactura().contains(NOMBRE_PRODUCTO),
                "La factura debe incluir el nombre del producto");
        }

        @Test
        @DisplayName("Debería incluir el precio en la factura")
        void testFacturaContienePrecio() {
            assertTrue(producto.generarTextoFactura().contains(String.valueOf(PRECIO_PRODUCTO)),
                "La factura debe incluir el precio del producto");
        }
    }

    @Nested
    @DisplayName("Pruebas de casos especiales")
    class CasosEspeciales {
        
        @Test
        @DisplayName("Debería manejar nombres largos correctamente")
        void testNombreLargo() {
            String nombreLargo = "Hamburguesa Mexicana Especial con Guacamole";
            ProductoMenu productoEspecial = new ProductoMenu(nombreLargo, 28000);
            
            assertTrue(productoEspecial.generarTextoFactura().contains(nombreLargo),
                "La factura debe soportar nombres largos de productos");
        }

        @Test
        @DisplayName("Debería manejar precio cero correctamente")
        void testPrecioCero() {
            ProductoMenu productoSinCosto = new ProductoMenu("promoción", 0);
            assertEquals(0, productoSinCosto.getPrecio(),
                "El producto con precio cero debe manejarse correctamente");
        }
    }
}